import sys
import re

def get_nex_ip(file):
    with open(file) as f:
        for line in f:   
            iterObj=re.finditer(r'\s\d{1,3}\.\d{1,3}.\d{1,3}.\d{1,3}\s',line)
            for matchObj in iterObj:      
                ip=matchObj.group(0).strip()
                good_ip=True
                for bajt in ip.split("."):
                    if (int(bajt) < 0) or (int(bajt) > 255):
                        good_ip=False
                if good_ip:
                    yield ip          

if len(sys.argv)>1:     
    plik=sys.argv[1]       

plik="plik_zad3.txt"
    
print('W {} znaleziono adresy:'.format(plik))    
for ip in get_nex_ip(plik):
    print(ip)

    