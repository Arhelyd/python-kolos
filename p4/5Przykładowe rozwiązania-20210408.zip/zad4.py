import re

#przykladowe pesele
p=['86242335618', 
'82121199232',
'45122317876',
'98031252482',
'66022553139',
'66022553139z',
'66022553039',
'660225y53039',
'166022553039',
'86323084635',
'63040697555',
'61030463386',
'65212775511']  

def check_pesel(pesel):

    #dekodowanie
    reg_pesel=re.compile(
    r'''(?P<rok>\d{2})
        (?P<miesiac>\d{2})
        (?P<dzien>\d{2})
        ...
        (?P<plec>\d)
        .$
    ''',
    re.X
    )
        
    matchObj=reg_pesel.match(pesel)
    if matchObj:
        pd=matchObj.groupdict()
    else:
        return "Niedozwolony znak lub niepoprawna długość!"    
    
    #suma kontrolna 
    pn=[int(x) for x in list(pesel)]
    wagi=[9,7,3,1,9,7,3,1,9,7]
    suma=0
    for i in range(10):
        suma=suma+wagi[i]*pn[i]
    if suma%10 != pn[10]:
        return "Niepoprawna suma konrtolna"
 
    #plec    
    if int(pd['plec'])%2 == 1:
        plec='mezczyzna'
    else:
        plec='kobieta'

    #dzien    
    dzien=int(pd['dzien'])

    #miesiąc
    miesiac=int(pd['miesiac'])%20

    #rok
    nr_stulecia=int(pd['miesiac'])//20
    mapa_stuleci={0:1900,1:2000,2:2100,3:2200,4:1800}
    rok=mapa_stuleci[nr_stulecia] + int(pd['rok'])
    return "%02d-%02d-%04d  %s" %(dzien, miesiac, rok, plec)    


for pesel in p:
    print(pesel,': ', check_pesel(pesel))    

    