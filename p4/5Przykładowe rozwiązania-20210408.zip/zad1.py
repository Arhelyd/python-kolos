def fun(fname, width=10):
    with open(fname) as f:
        while True:
            line=f.read(width)
            if not line:
                break
            yield line.replace('\n',' ')        

for i in fun("plik_zad1.txt",5):
    print(i)
    