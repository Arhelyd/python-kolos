def fun(fname, width=10):
    with open(fname) as f:
        while True:
            line=f.readline()
            if not line:
                break
            for word in line.replace('\n',' ').split():
                for subword in [word[i:i+width] for i in range(0,len(word),width)]:
                    yield(subword.center(width))
                          
for i in fun("plik_zad2.txt",10):
    print(i)
    