import math
def sqrt(x):
    try:
        result=math.sqrt(x)
    except (ValueError) as ex:
        print('1) ValueError: "%s". ' %ex, end='')
    except (TypeError) as ex:
        print('2) TypeError: "%s". ' %ex, end='')   
    except (OverflowError) as ex:
        print('3) OverflowError: "%s". ' %ex, end='')       
    else:
        print('Brak wyjatku. ', end='')    
        return result
    finally :   
        print('Funkcja zwraca: ', end='')
        
#brak wyjątku        
print(sqrt(10))
#ValueError
print(sqrt(-1))
#TypeError
print(sqrt('s'))
#OverflowError
print(sqrt(10**(10000)))
