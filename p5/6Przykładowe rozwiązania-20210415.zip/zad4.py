import os, sys, glob, tarfile

# katalog testowy
test_dir=os.getenv('HOMEDRIVE')+ os.getenv('HOMEPATH') + '/testy'
print("Test dir:\n   %s" %(os.path.normpath(test_dir)))
if not os.path.isdir(test_dir):
    try:
        os.mkdir(test_dir)
    except:
        print('Katalog testowy istnieje lub inny błąd!')
        exit()

# katalog Python'a    
ppath='C:/Users/mwisniew/AppData/Local/Programs/Python/Python38/'
print("Python's dir:\n   %s" %(ppath))        

# liczba plików i rozmiar  
size=0
licz=0
for i in glob.iglob(ppath + '/*'):
    size+=os.path.getsize(i)
    licz+=1
print("Liczba plików: %d, rozmiar: %d B" %(licz, size))    

#exit()
# test kompresji
tar_test=[
{'aname':test_dir + '/ppath.tar', 'amode':'x:', 'asize':0},
{'aname':test_dir + '/ppath.tar.gz', 'amode':'x:gz', 'asize':0},
{'aname':test_dir + '/ppath.tar.bz2', 'amode':'x:bz2', 'asize':0},
{'aname':test_dir + '/ppath.tar.xz', 'amode':'x:xz', 'asize':0}
]
 
for tf in tar_test: 
    print("Tworzenie:\n   ", os.path.normpath(tf['aname']),tf['amode'],tf['asize'])
    try:
        ftar=tarfile.open(tf['aname'],tf['amode']) 
        for file in glob.iglob(ppath+"/*.*"):
            ftar.add(os.path.normpath(file))
        ftar.close()
        tf['asize']=os.path.getsize(tf['aname'])
    except FileExistsError as ex:
        print('Archiwum juz istnieje!', ex)
    except Exception as e:  
        print('Inny błąd!', str(e))
 
# wyniki
print("Wyniki:")
for tf in tar_test: 
    tf['asize']=os.path.getsize(tf['aname'])
    print('   tryb: ',tf['amode'],'; size: ', tf['asize'],'B')
        
        
#TestDir = "d:/testy"
#Folder = 'd:/rob/'        