import re

class MailAddresError(Exception):
    '''Wyjątek - niepoprawny adres email'''
    
class adres:
    def __init__(self, adres):
        self.adres=self.__parser(adres)
    def __call__(self, adres):
        self.adres=self.__parser(adres)
    def __parser(self,adres):
        matchObj=re.fullmatch(r'''
                    \w+
                    (\.\w+)*
                    @\w+(\.\w+)+'''
                    ,adres,flags=re.VERBOSE|re.ASCII)
        if matchObj:
            return adres
        else:           
            raise MailAddresError('wyjatek: adres "%s" jest nieprawidlowy' %adres)
    def set_adres(self, adres):
        self.adres=self.__parser(adres)
    def __str__(self):
        return "%s" %(self.adres)

#zły adres próba        
try:        
    a=adres('j.kowalski.@gmail.com')
except MailAddresError as ex:
    print(ex)
else:
    print("adres '%s' jest prawidlowy" %a)

print()


#dobry adres próba
try:        
    b=adres('j.kowalski@gmail.com')
except MailAddresError as ex:    
    print(ex)
else:
    print("adres '%s' jest prawidlowy" %b)

